package com.AngelHackDemoApp.Utitlities;

import android.app.Activity;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.ViewFlipper;

public class Variables extends Activity{

	
	public ViewFlipper vfMainHolder;
	public ViewFlipper vfSubMainHolder;
	public ViewFlipper vfdrawer;
	public ViewFlipper vfMain;
	
	public TextView tvHeaderTItle;
	public ImageButton ivHeaderMenu;

	public int REQUEST_VIDEO_CAPTURE = 1;
	public int REQUEST_PHOTO_CAPTURE = 1;
}
