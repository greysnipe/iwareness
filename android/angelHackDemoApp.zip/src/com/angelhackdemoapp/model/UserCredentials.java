package com.AngelHackDemoApp.model;

public class UserCredentials {

	private String UserName;

	public String getUserName() {
		return UserName;
	}

	public void setUserName(String userName) {
		UserName = userName;
	}
	
}
